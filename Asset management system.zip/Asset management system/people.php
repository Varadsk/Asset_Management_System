<?php
    include("Header.php")
?>
            <!-- <input class="btn" type="submit" name="" value="ADD NEW"> -->
            <button id="button" class="btn">ADD NEW</button>
            <div class="tablecrd">
                <table class="tablel">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Title</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>user name</th>
                            <th>department</th>
                            <th>location</th>
                            <th>Manager</th>
                            <th>Total assets</th>
                            <th>Total acceserise</th>
                            <th>Total Licences</th>
                            
                        </tr>
                    </thead>
                    <tr>
                        <td>M.K.Mane </td>
                        <td>Sr Supervisor</td>
                        <td>ssm@gmail.com</td>
                        <td>8989898989</td>
                        <td>ssm</td>
                        <td>Sales</td>
                        <td>Kolhapur </td>
                        <td>supervisory </td>
                        <td>10 </td>
                        <td>20</td>
                        <td>10</td>
                        
                        
                    </tr>
                 
                       
                    </tr>
                </table>
            </div>
            <div class="popup-comtainer">
                <div class="card_add">
                    <div class="addnew">
                        <form action="">
                            <div class="close"><i class="fas fa-times"></i></div>
                            <h2 style="margin-top:20px; margin-left:20px; color:white; font-weight: bolder;">ADD NEW ASSET</h2>
                            <label  for="fname">Asset Name:</label>
                            <input type="text" id="Title" class="textbox" style="margin-left: 100px;"><br>

                            <label  for="fname">Asset Tag:</label>
                            <input type="text" id="Title" class="textbox" style="margin-left: 119px;"><br>

                            <label  for="fname">Serial No:</label>
                            <input type="text" id="Title" class="textbox" style="margin-left: 119px;"><br>

                            <label  for="fname">Model:</label>
                            <input type="text" id="Title" class="textbox" style="margin-left: 145px;"><br>

                            <label  for="fname">Catagory:</label>
                            <input type="text" id="Title" class="textbox" style="margin-left: 119px;"><br>

                            <label  for="fname">Status:</label>
                            <input type="text" id="Title" class="textbox" style="margin-left: 145px;"><br>

                            <label  for="fname">Check-out to:</label>
                            <input type="text" id="Title" class="textbox" style="margin-left: 93px;"><br>

                            <label  for="fname">Location:</label>
                            <input type="text" id="Title" class="textbox" style="margin-left: 125px;"><br>

                            <label  for="fname">Purchase cost:</label>
                            <input type="text" id="Title" class="textbox" style="margin-left: 85px;"><br>

                            <input type="submit" value="SUBMIT" class="add-btn">
                        </form>
                    </div>
                </div>
                <!-- <div class="close"><i class="fas fa-times"></i></div> -->
            </div>
            <script src="popup.js"></script>