-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 03, 2020 at 05:03 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `assetm`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_repo`
--

CREATE TABLE IF NOT EXISTS `activity_repo` (
  `Date` datetime(6) NOT NULL,
  `admin` varchar(20) NOT NULL,
  `action` varchar(20) NOT NULL,
  `type` text NOT NULL,
  `item` varchar(20) NOT NULL,
  `to` varchar(20) NOT NULL,
  `notes` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `asset`
--

CREATE TABLE IF NOT EXISTS `asset` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `Asset_name` varchar(40) NOT NULL,
  `Asset_tag` varchar(40) NOT NULL,
  `serial` varchar(40) NOT NULL,
  `model` varchar(40) NOT NULL,
  `category` text NOT NULL,
  `status` text NOT NULL,
  `checkout_to` varchar(40) NOT NULL,
  `location` text NOT NULL,
  `purchase_cost` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=56 ;

--
-- Dumping data for table `asset`
--

INSERT INTO `asset` (`id`, `Asset_name`, `Asset_tag`, `serial`, `model`, `category`, `status`, `checkout_to`, `location`, `purchase_cost`) VALUES
(1, 'asus', '1234', '987654321', 'X540L', 'laptop', 'dep', 'vk', 'kop', 30000),
(15, 'Router', 'R501', '101R', '2057U', 'IT', 'Deployed', 'VK', 'Pune', 9000),
(44, 'Dell', 'G6F457', 'SEWXZSD123', 'OPTIPLEX', 'IT', 'DEPLOYED', 'SAI15', 'KOLHAPUR', 2300),
(45, 'HP', 'SDFRECA15', 'HTVVGBCVG129', 'PAVILION', 'IT', 'UNDEPLOYED', 'Varad8', 'KOLHAPUR', 2390),
(46, 'ASUS', 'V456SWET2A', 'SWEC2398FG', 'VIVOBOOK', 'IT', 'DEPLOYED', 'PD1756', 'KOLHAPUR', 4500),
(47, 'ASUS', 'SFFEBJGTU87', 'LOJGBFYFFY60', 'ROG', 'IT', 'REQUESTED', 'XS5369', 'KOLHAPUR', 1200),
(48, 'APPLE', 'SDGFDVCES592', 'XHGJHKCVN410', 'AIR', 'IT', 'DEPLOYED', 'varad8', 'KOLHAPUR', 90000),
(49, 'DELL', 'XFJIOPDE77', 'BFTRSQLIDH2313', 'ALIENWARE', 'IT', 'DEPLOYED', 'VK', 'KOLHAPUR', 70000),
(50, 'HP', 'DSDSDSD2345', 'HNUFRTIVS14', '15Q', 'IT', 'DEPLOYED', 'SAI15', 'KOLHAPUR', 60000),
(51, 'LENOVO', 'JKHKHH34DE', 'XGLIOPDER94', 'YOGA', 'IT', 'DEPLOYED', 'varad8', 'KOLHAPUR', 45000),
(52, 'LENOVO', 'GSFHSGFS3487', 'VFGHUTEROI90', 'S540', 'IT', 'DEPLOYED', 'vk', 'KOLHAPUR', 35000),
(53, 'ACER', 'DGBIUGRESDOCXD', 'WECXSNJUIRF5498', 'PREDIATOR', 'IT', 'UNDEPLOYED', 'VK', 'KOLHAPUR', 70000),
(54, 'SONY', 'GTDEEUEJ2345', 'KINFVDER86', 'VIO', 'IT', 'DEPLOYED', 'SAI15', 'KOLHAPUR', 50000),
(55, 'ACER', 'HTYVDR75498', 'VBGTOIKSE0969', 'X680', 'IT', 'DEPLOYED', 'SAI15', 'KOLHAPUR', 45000);

-- --------------------------------------------------------

--
-- Table structure for table `asset_disposed`
--

CREATE TABLE IF NOT EXISTS `asset_disposed` (
  `id` int(5) NOT NULL,
  `Asset_name` varchar(40) NOT NULL,
  `Asset_tag` varchar(40) NOT NULL,
  `serial` varchar(40) NOT NULL,
  `model` varchar(40) NOT NULL,
  `category` text NOT NULL,
  `status` text NOT NULL,
  `checkout_to` varchar(40) NOT NULL,
  `location` text NOT NULL,
  `purchase_cost` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `asset_disposed`
--

INSERT INTO `asset_disposed` (`id`, `Asset_name`, `Asset_tag`, `serial`, `model`, `category`, `status`, `checkout_to`, `location`, `purchase_cost`) VALUES
(0, '', '', '', '', '', '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `audit_report`
--

CREATE TABLE IF NOT EXISTS `audit_report` (
  `Audit` text NOT NULL,
  `Admin` text NOT NULL,
  `Item` varchar(100) NOT NULL,
  `Location` text NOT NULL,
  `Next_audit_date` date NOT NULL,
  `Days_to_audit` int(11) NOT NULL,
  `Notes` text NOT NULL,
  UNIQUE KEY `Item` (`Item`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `licences`
--

CREATE TABLE IF NOT EXISTS `licences` (
  `licences` varchar(30) NOT NULL,
  `product_key` varchar(30) NOT NULL,
  `expiration date` date NOT NULL,
  `licences to mail` varchar(30) NOT NULL,
  `to name` text NOT NULL,
  `manufacturer` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `licences_report`
--

CREATE TABLE IF NOT EXISTS `licences_report` (
  `company` text NOT NULL,
  `licence` varchar(40) NOT NULL,
  `product_key` varchar(40) NOT NULL,
  `seats` int(30) NOT NULL,
  `remaining_seats` int(30) NOT NULL,
  `expiration_date` date NOT NULL,
  `purchase_date` date NOT NULL,
  `purchase_cost` int(30) NOT NULL,
  `value` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`) VALUES
('ADMIN', 'abcd@123');

-- --------------------------------------------------------

--
-- Table structure for table `maintainance_report`
--

CREATE TABLE IF NOT EXISTS `maintainance_report` (
  `Asset_Name` varchar(20) NOT NULL,
  `Supplier` varchar(20) NOT NULL,
  `Type_of_Asset` varchar(20) NOT NULL,
  `start_date` date NOT NULL,
  `completed_date` date NOT NULL,
  `maintainance_time` datetime(6) NOT NULL,
  `cost` int(10) NOT NULL,
  `admin` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `people`
--

CREATE TABLE IF NOT EXISTS `people` (
  `name` text NOT NULL,
  `title` text NOT NULL,
  `email` varchar(30) NOT NULL,
  `phone` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `department` text NOT NULL,
  `location` text NOT NULL,
  `manager` text NOT NULL,
  `total_assets` int(40) NOT NULL,
  `total_accessories` int(40) NOT NULL,
  `total_licences` int(40) NOT NULL,
  `notes` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
