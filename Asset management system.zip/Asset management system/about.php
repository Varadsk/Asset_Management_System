<?php
    include("Header.php");
?>
        <h2 style="text-align: center; margin-top: 10%;font-size : 35px">Always happy to help you!</h2>
        <div class="text">
            <p><h5>industry type: industrial asset management</h5></p>
            <p><h5>founded in: 2019-20</h5></p>
            <p><h5>Area served: Across the country.</h5></p>
            <p><h5>Key peoples: TY Computers</h5></p>
            <p><h5>Owner: AssetM co.</h5></p>
            <p><h5>Contact number: 1800 123 456 </h5></p> 
            <p><h5>Rights Reserved to:©AssetM co.</h5></p> 
        </div>
    </body>
</html>