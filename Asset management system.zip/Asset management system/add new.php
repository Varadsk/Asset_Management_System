<?php
    include("Header.php")
?>
<div class="card_add">
    <div class="addnew">
        <form action="">
            <h2 style="margin-top:20px; margin-left:20px; color:white; font-weight: bolder;">ADD NEW ASSET</h2>
            <label  for="fname">Asset Name:</label>
            <input type="text" id="Title" class="textbox" style="margin-left: 100px;"><br>

            <label  for="fname">Asset Tag:</label>
            <input type="text" id="Title" class="textbox" style="margin-left: 119px;"><br>

            <label  for="fname">Serial No:</label>
            <input type="text" id="Title" class="textbox" style="margin-left: 119px;"><br>

            <label  for="fname">Model:</label>
            <input type="text" id="Title" class="textbox" style="margin-left: 145px;"><br>

            <label  for="fname">Catagory:</label>
            <input type="text" id="Title" class="textbox" style="margin-left: 119px;"><br>

            <label  for="fname">Status:</label>
            <input type="text" id="Title" class="textbox" style="margin-left: 145px;"><br>

            <label  for="fname">Check-out to:</label>
            <input type="text" id="Title" class="textbox" style="margin-left: 93px;"><br>

            <label  for="fname">Location:</label>
            <input type="text" id="Title" class="textbox" style="margin-left: 125px;"><br>

            <label  for="fname">Purchase cost:</label>
            <input type="text" id="Title" class="textbox" style="margin-left: 85px;"><br>

            <input type="submit" value="SUBMIT" class="add-btn">
        </form>
    </div>
</div>
