<?php
    session_start();
    include("header.php");
    @mysql_connect('localhost', 'root', '')or die('cannot connectssss'); 
    mysql_select_db('assetm')or die('cannot select DB');
    $sql="SELECT * FROM  `asset`"; 
    $result=mysql_query($sql);
    if($result==false ){die(mysql_error());}
    $row=mysql_fetch_array($result);  
    $count=mysql_num_rows($result);
?>
    <!-- <div id="one" class="slideswitch"></div>
    <div id="two" class="slideswitch"></div>

    <div class="pagination">
        <a id="pagination_one" href="#one"><i class="fas fa-chevron-left"></i></a>
        <a id="pagination_two" href="#two"><i class="fas fa-chevron-right"></i></a>
    </div>

    <div class="wrapper">
        <div id="one" class="section"> -->
            <!-- <div class="tablecrd"> -->
            <button id="button" class="btn" style="margin-left: 260px;">ADD NEW</button>
            <form action="del.php" method="POST">
                <table class="table0">
                    <thead>
                        <tr>
                            <th style="min-width: 170px">Asset Name</th>
                            <th style="min-width: 170px">Asset Tag</th>
                            <th style="min-width: 170px">Serial</th>
                            <th style="min-width: 170px">Model</th>
                            <th style="min-width: 170px">Category</th>
                            <th style="min-width: 170px">Status</th>
                            <th style="min-width: 170px">Checked Out To</th>
                            <th style="min-width: 170px">Location</th>
                            <th style="min-width: 170px">Purches</th>
                            <th style="min-width: 170px">Action</th>
                        </tr>
                    </thead>
                    <?php
                        // $count= mysql_num_rows($count)
                        //echo $count;
                        for ($i=0; $i<$count; $i++) { 
                            $id = $row['id'];
                            $Asset_name=$row['Asset_name'];
                            $Asset_tag=$row['Asset_tag'];
                            $serial=$row['serial'];
                            $model=$row['model'];
                            $category=$row['category'];
                            $status=$row['status'];
                            $checkout_to=$row['checkout_to'];
                            $location=$row['location'];
                            $purchase_cost=$row['purchase_cost'];
                    ?>
                    <tr>
                        <td>
                            <?php
                                echo $Asset_name;
                            ?>
                        </td>
                        <td>
                            <?php
                                echo $Asset_tag;
                            ?>
                        </td>
                        <td>
                            <?php
                                echo $serial;
                            ?>
                        </td>
                        <td>
                            <?php
                                echo $model;
                            ?>
                        </td>
                        <td>
                            <?php
                                echo $category;
                            ?>
                        </td>
                        <td>
                            <?php
                                echo $status;
                            ?>
                        </td>
                        <td>
                            <?php
                                echo $checkout_to;
                            ?>
                        </td>
                        <td>
                            <?php
                                echo $location;
                            ?>
                        </td>
                        <td>
                            <?php
                                echo $purchase_cost;
                            ?>
                        </td>
                        <td>
                            <button type="EDIT" name="Edit" class="edit"><i class="fas fa-pencil-alt" style="size:20px;"></i></button>
                            <button type="DELETE" name="DEL" class="del"><i class="far fa-trash-alt"></i></button>
                            <?php  
                                $_SESSION['id']= $id;
                            ?>
                        </td>
                    </tr>
                    <?php
                            $row=mysql_fetch_array($result);  
                        }
                    ?>
                </table>
            </form>
        </div>
        </div>
    <div class="popup-comtainer" style="height: 690px;">
        <div class="card_add">
                <div class="addnew">
                    <form action="insert.php" method="POST">
                        <div class="close"><i class="fas fa-times"></i></div>
                            <h2 style="margin-top:20px; margin-left:20px; color:white; font-weight: bolder;">ADD NEW ASSET</h2>
                            <label  for="fname">Asset Name:</label>
                            <input type="text" id="Title" class="textbox" style="margin-left: 100px;" name="an" pattern="^[A-Za-z]{1,30}$" title="Must contain charchters only and cannot contain special symbols"><br>

                            <label  for="fname">Asset Tag:</label>
                            <input type="text" id="Title" class="textbox" style="margin-left: 119px;" name="at" pattern="[A-Za-z0-9]{1,40}$" title="Must contain alphanumeric and cannot contain special symbols"><br>

                            <label  for="fname">Serial No:</label>
                            <input type="text" id="Title" class="textbox" style="margin-left: 119px;" name="sn" pattern="[A-Za-z0-9]{1,40}$" title="Must contain alphanumeric and cannot contain special symbols" ><br>

                            <label  for="fname">Model:</label>
                            <input type="text" id="Title" class="textbox" style="margin-left: 145px;" name="mod" pattern="[A-Za-z0-9]{1,40}$" title="Must contain alphanumeric and cannot contain special symbols" ><br>

                            <label  for="fname">Catagory:</label>
                            <input type="text" id="Title" class="textbox" style="margin-left: 119px;" name="cat" pattern="^[A-Za-z]{1,30}$" title="Must contain charchters only and cannot contain special symbols" ><br>

                            <label  for="fname">Status:</label>
                            <input type="text" id="Title" class="textbox" style="margin-left: 145px;" name="st" pattern="^[A-Za-z]{1,40}$" title="Must contain charchters only and cannot contain special symbols"><br>

                            <label  for="fname">Check-out to:</label>
                            <input type="text" id="Title" class="textbox" style="margin-left: 93px;" name="cot" pattern="^[A-Za-z0-9_]{1,10}$"  title="Must contain only letters,numbers and underscore no more than 10 charachters"><br>

                            <label  for="fname">Location:</label>
                            <input type="text" id="Title" class="textbox" style="margin-left: 125px;" name="loc"pattern="^[A-Za-z]{1,30}$" title="Must contain charchters only and cannot contain special symbols"><br>

                            <label  for="fname">Purchase cost:</label>
                            <input type="text" id="Title" class="textbox" style="margin-left: 85px;" name="pc" pattern="^[0-9]{1,45}$" title="Must contain numeric values only and cannot contain special symbols"><br>

                            <input type="SUBMIT" name="SUBMIT" value="SUBMIT" class="add-btn">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>                

<script src="popup.js"></script>