<?php
    session_start();
    $servername ="127.0.0.1";
    $username="root";
    $pass="";
    $db="assetm";
        
    $con = new mysqli($servername,$username,$pass,$db);
    echo "in del";
    if($con -> connect_error){die("connection failed");}
            
    echo "connection successful "; 
    
    $delid = $_SESSION['id'];
    if(isset($_POST['DEL']))
    {
        $sql="SELECT * FROM `asset` WHERE $delid"; 
        $result=mysqli_query($con,$sql);
        if($result==false ){die(mysql_error());}
        $row=mysql_fetch_array($result);
            $an=$row['Asset_name'];
            $at=$row['Asset_tag'];
            $sn=$row['serial'];
            $mod=$row['model'];
            $cat=$row['category'];
            $st=$row['status'];
            $cot=$row['checkout_to'];
            $loc=$row['location'];
            $pc=$row['purchase_cost'];  
            echo "$an";

            // $sql2 = "insert into `asset_disposed`(`Asset_name`, `Asset_tag`, `serial`, `model`, `category`, `status`, `checkout_to`, `location`, `purchase_cost`) values ('$an','$at','$sn','$mod','$cat','$st','$cot','$loc','$pc')";
            $sql2 = "INSERT INTO `asset`(`Asset_name`, `Asset_tag`, `serial`, `model`, `category`, `status`, `checkout_to`, `location`, `purchase_cost`) VALUES ('$an','$at','$sn','$mod','$cat','$st','$cot','$loc','$pc')";
            $res =  mysqli_query($con,$sql2);
            if(!$res)
            {
                echo "yes";
            }
            else
            {
               echo " QQQQ not";
            }

        $sqll = "DELETE FROM `asset` WHERE id = $delid";
        $res =  mysqli_query($con,$sqll);
        if($res)
        {
            echo "del";
        }
        else
        {
            echo " q not";
        }
        session_destroy();
        header('Location: asset1.php');	
    }
?>