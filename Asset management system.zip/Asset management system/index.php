<?php
    
    $password =$_post['pass'];
    $username =$_post['user'];

    $username = stripcslashes($username);
    $password = stripcslashes($password);
    $username = mysql_real_escape_string($username);
    $password = mysql_real_escape_string($password);

    mysql_connect("localhost","root","");
    mysql_select_db("assetm");

    $result = mysql_query("SELECT * FROM login WHERE username = '$username' and password = '$password'") or die("failed to query database".mysql_error());
    $row = mysql_fetch_array($result)
    if($row['username']==$username && $row['password']==$password){
        header('Location: firstpage.php');
    }else{
        echo "failed to login";
    }        
?>





<html>
<head>
    <title>ASSET MANAGEMENT</title>
    <link rel="stylesheet" type="text/css" href="css/index.css">
</head>
<body> 
    <div class="Alogin">
        <img src ="images/logo1.jpg" class="Aicon" style="background-color: rgb(0, 204, 255);border: rgb(0, 204, 255);">
        <h1>LOGIN HERE</h1>
        <form action ="firstpage.php" method="post">
            <p>Username</p>
            <input type="password" name="" placeholder="Enter Username" id="user" pattern="^[A-Za-z0-9_]{1,10}$"  title="Must contain only letters,numbers and underscore no more than 10 charachters">
            
            <p>Password</p>
            <input type="password" name="" placeholder="Enter Password" id= "pass" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters">
            <input type="submit" name="" value="LOGIN">
            <a href ="#">Forget password?</a>
            <a href = "Home.html"></a>
        </form>
    </div>
</body>
</html>