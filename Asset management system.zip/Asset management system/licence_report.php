<?php
    include("Header.php")
?>
            <div class="tablecrd">
                <table class="tablel">
                    <thead>
                        <tr>
                            <th>Company</th>
                            <th>Licence</th>
                            <th>Product key</th>
                            <th>Seats</th>
                            <th>Remaining seats</th>
                            <th>Expiration date</th>
                            <th>Purchase date</th>
                            <th>Purchase cost</th>
                            <th>Value</th>
                        </tr>
                    </thead>
                    <tr>
                        <td>Alfreds </td>
                        <td>Maria Anders</td>
                        <td>Germany</td>
                        <td>Alfreds </td>
                        <td>Maria Anders</td>
                        <td>Germany</td>
                        <td>Alfreds </td>
                        <td>Maria Anders</td>
                        <td>Germany</td>
                    </tr>
                    <tr>
                        <td>Centro </td>
                        <td>Francisco Chang</td>
                        <td>Mexico</td>
                        <td>Centro </td>
                        <td>Francisco Chang</td>
                        <td>Mexico</td>
                        <td>Centro </td>
                        <td>Francisco Chang</td>
                        <td>Mexico</td>
                    </tr>
                    <tr>
                        <td>Ernst Handel</td>
                        <td>Roland Mendel</td>
                        <td>Austria</td>
                        <td>Ernst Handel</td>
                        <td>Roland Mendel</td>
                        <td>Austria</td>
                        <td>Ernst Handel</td>
                        <td>Roland Mendel</td>
                        <td>Austria</td>
                    </tr>
                    <tr>
                        <td>Island Trading</td>
                        <td>Helen Bennett</td>
                        <td>UK</td>
                        <td>Island Trading</td>
                        <td>Helen Bennett</td>
                        <td>UK</td>
                        <td>Island Trading</td>
                        <td>Helen Bennett</td>
                        <td>UK</td>
                    </tr>
                    <tr>
                        <td>Laughing </td>
                        <td>Yoshi Tannamuri</td>
                        <td>Canada</td>
                        <td>Laughing </td>
                        <td>Yoshi Tannamuri</td>
                        <td>Canada</td>
                        <td>Laughing </td>
                        <td>Yoshi Tannamuri</td>
                        <td>Canada</td>
                    </tr>
                    <tr>
                        <td>Magazzini</td>
                        <td>Giovanni Rovelli</td>
                        <td>Italy</td>
                        <td>Magazzini</td>
                        <td>Giovanni Rovelli</td>
                        <td>Italy</td>
                        <td>Magazzini</td>
                        <td>Giovanni Rovelli</td>
                        <td>Italy</td>
                    </tr>
                </table>
            </div>