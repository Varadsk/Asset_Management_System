<?php
    include("Header.php");
?>
    <body>
        <h2 style="text-align: center; margin-top: 10%;font-size : 35px">How it Works?</h2>
        <div class="text">
            <h4>Steps for user guideline:</h4>

            <p><h5>1. Enter to the Website.</h5></p>
            <p><h5>2. See the different options on your home screen.</h5></p>
            <p><h5>3. Select the correct option as per your requirement.</h5></p>
            <p><h5>4. See the details of selected option.</h5></p>
            <p><h5>5. If you want contact us register to the website.</h5></p>
            <p><h5>6. Enter the details required to the website and click on next.</h5></p> 
        </div>
    </body>
</html>