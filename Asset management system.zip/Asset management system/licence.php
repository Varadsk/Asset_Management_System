<?php
    include("Header.php")
?>
            <!-- <input class="btn" type="submit" name="" value="ADD NEW"> -->
            <button id="button" class="btn">ADD NEW</button>
            <div class="tablecrd">
                <table class="tablel">
                    <thead>
                        <tr>
                        <th style="min-width: 120px">Licence</th>
                            <th style="min-width: 220px">Product key</th>
                            <th style="min-width: 150px">Expiry date</th>
                            <th style="min-width: 140px">Remaining seats</th>
                            <th style="min-width: 200px">Licenes to mail</th>
                            <th style="min-width: 150px">Author</th>
                            <th style="min-width: 170px">Manufacturer</th>
                            <th style="min-width: 170px">Action</th>
                            
                        </tr>
                    </thead>
                    <tr>
                        <td>Alfreds </td>
                        <td>Maria Anders</td>
                        <td>Germany</td>
                        <td>Alfreds </td>
                        <td>Maria Anders</td>
                        <td>Germany</td>
                        <td>Alfreds </td>
                        
                    </tr>
                    <tr>
                        <td>Centro </td>
                        <td>Francisco Chang</td>
                        <td>Mexico</td>
                        <td>Centro </td>
                        <td>Francisco Chang</td>
                        <td>Mexico</td>
                        <td>Centro </td>
                        
                    </tr>
                    <tr>
                        <td>Ernst Handel</td>
                        <td>Roland Mendel</td>
                        <td>Austria</td>
                        <td>Ernst Handel</td>
                        <td>Roland Mendel</td>
                        <td>Austria</td>
                        <td>Ernst Handel</td>
                        
                    </tr>
                    <tr>
                        <td>Island Trading</td>
                        <td>Helen Bennett</td>
                        <td>UK</td>
                        <td>Island Trading</td>
                        <td>Helen Bennett</td>
                        <td>UK</td>
                        <td>Island Trading</td>
                        
                    </tr>
                    <tr>
                        <td>Laughing </td>
                        <td>Yoshi Tannamuri</td>
                        <td>Canada</td>
                        <td>Laughing </td>
                        <td>Yoshi Tannamuri</td>
                        <td>Canada</td>
                        <td>Laughing </td>
                       
                    </tr>
                    <tr>
                        <td>Magazzini</td>
                        <td>Giovanni Rovelli</td>
                        <td>Italy</td>
                        <td>Magazzini</td>
                        <td>Giovanni Rovelli</td>
                        <td>Italy</td>
                        <td>Magazzini</td>
                       
                    </tr>
                    <tr>
                        <td>Magazzini</td>
                        <td>Giovanni Rovelli</td>
                        <td>Italy</td>
                        <td>Magazzini</td>
                        <td>Giovanni Rovelli</td>
                        <td>Italy</td>
                        <td>Magazzini</td>
                       
                    </tr>
                </table>
            </div>
            <div class="popup-comtainer" style="height: 550px;">
                <div class="card_add">
                    <div class="addnew">
                        <form action="">
                            <div class="close"><i class="fas fa-times"></i></div>
                            <h2 style="margin-top:20px; margin-left:20px; color:white; font-weight: bolder;">ADD NEW LICENCE</h2>
                            <label  for="fname">Licence:</label>
                            <input type="text" id="Title" class="textbox" style="margin-left: 100px;"><br>

                            <label  for="fname">Product Key:</label>
                            <input type="text" id="Title" class="textbox" style="margin-left: 64px;"><br>

                            <label  for="fname">Expiry Date:</label>
                            <input type="text" id="Title" class="textbox" style="margin-left: 64px;"><br>

                            <label  for="fname">Remaining sets:</label>
                            <input type="text" id="Title" class="textbox" style="margin-left: 39px;"><br>

                            <label  for="fname">Licences to mail:</label>
                            <input type="text" id="Title" class="textbox" style="margin-left: 32px;"><br>

                            <label  for="fname">Author:</label>
                            <input type="text" id="Title" class="textbox" style="margin-left: 105px;"><br>

                            <label  for="fname">Manufacturer:</label>
                            <input type="text" id="Title" class="textbox" style="margin-left: 50px;"><br>

                            <input type="submit" value="SUBMIT" class="add-btn" style="margin-bottom: 50px;">
                        </form>
                    </div>
                </div>
                <!-- <div class="close"><i class="fas fa-times"></i></div> -->
            </div>
            <script src="popup.js"></script>