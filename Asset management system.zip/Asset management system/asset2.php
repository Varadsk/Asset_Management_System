<?php
    include("Header.php")
?>
    <!-- <input class="btn" type="submit" name="" value="ADD NEW"> -->
    <button class="btn">ADD NEW</button>
    <div class="tablecrd">
        <table>
            <thead>
                <tr>
                    <th>Asset Name</th>
                    <th>Device Image</th>
                    <th>Asset Tag</th>
                    <th>Serial</th>
                    <th>Model</th>
                    <th>Category</th>
                    <th>Status</th>
                    <th>Checked Out To</th>
                    <th>Location</th>
                </tr>
            </thead>
            <tr>
                <td>Alfreds </td>
                <td>Maria Anders</td>
                <td>Germany</td>
                <td>Alfreds </td>
                <td>Maria Anders</td>
                <td>Germany</td>
                <td>Alfreds </td>
                <td>Maria Anders</td>
                <td>Germany</td>
            </tr>
            <tr class="active-row">
                <td>Centro </td>
                <td>Francisco Chang</td>
                <td>Mexico</td>
                <td>Centro </td>
                <td>Francisco Chang</td>
                <td>Mexico</td>
                <td>Centro </td>
                <td>Francisco Chang</td>
                <td>Mexico</td>
            </tr>
            <tr>
                <td>Ernst Handel</td>
                <td>Roland Mendel</td>
                <td>Austria</td>
                <td>Ernst Handel</td>
                <td>Roland Mendel</td>
                <td>Austria</td>
                <td>Ernst Handel</td>
                <td>Roland Mendel</td>
                <td>Austria</td>
            </tr>
            <tr class="active-row">
                <td>Island Trading</td>
                <td>Helen Bennett</td>
                <td>UK</td>
                <td>Island Trading</td>
                <td>Helen Bennett</td>
                <td>UK</td>
                <td>Island Trading</td>
                <td>Helen Bennett</td>
                <td>UK</td>
            </tr>
            <tr>
                <td>Laughing </td>
                <td>Yoshi Tannamuri</td>
                <td>Canada</td>
                <td>Laughing </td>
                <td>Yoshi Tannamuri</td>
                <td>Canada</td>
                <td>Laughing </td>
                <td>Yoshi Tannamuri</td>
                <td>Canada</td>
            </tr>
            <tr class="active-row">
                <td>Magazzini</td>
                <td>Giovanni Rovelli</td>
                <td>Italy</td>
                <td>Magazzini</td>
                <td>Giovanni Rovelli</td>
                <td>Italy</td>
                <td>Magazzini</td>
                <td>Giovanni Rovelli</td>
                <td>Italy</td>
            </tr>
        </table>
    </div>