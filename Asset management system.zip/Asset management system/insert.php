<?php
            $servername ="127.0.0.1";
            $username="root";
            $pass="";
            $db="assetm";
        
            $con = new mysqli($servername,$username,$pass,$db);
            if($con -> connect_error){die("connection failed");}
            
            echo "connection successful ";
            if(isset($_POST['SUBMIT']))
            {
                $an=$_POST["an"];
                $at=$_POST["at"];
                $sn=$_POST["sn"];
                $mod=$_POST["mod"];
                $cat=$_POST["cat"];
                $st=$_POST["st"];
                $cot=$_POST["cot"];
                $loc=$_POST["loc"];
                $pc=$_POST["pc"];

                $sqll = "INSERT INTO `asset`(`Asset_name`, `Asset_tag`, `serial`, `model`, `category`, `status`, `checkout_to`, `location`, `purchase_cost`) VALUES ('$an','$at','$sn','$mod','$cat','$st','$cot','$loc','$pc')";
                $res =  mysqli_query($con,$sqll);
                header('Location: asset1.php');	
            }
?>