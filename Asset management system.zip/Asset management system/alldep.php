<?php
    include("Header.php")
?>
            <!-- <input class="btn" type="submit" name="" value="ADD NEW"> -->
            <button id="button" class="btn">ADD NEW</button>
            <table class="tablel">
                    <thead>
                        <tr>
                            <th>Licence</th>
                            <th>Product key</th>
                            <th>Expiry date</th>
                            <th>Remaining seats</th>
                            <th>Licenes to mail</th>
                            <th>author</th>
                            <th>Manufacturer</th>
                            
                        </tr>
                    </thead>
                    <tr>
                        <td>Alfreds </td>
                        <td>Maria Anders</td>
                        <td>Germany</td>
                        <td>Alfreds </td>
                        <td>Maria Anders</td>
                        <td>Germany</td>
                        <td>Alfreds </td>
                        
                    </tr>
                    <tr>
                        <td>Centro </td>
                        <td>Francisco Chang</td>
                        <td>Mexico</td>
                        <td>Centro </td>
                        <td>Francisco Chang</td>
                        <td>Mexico</td>
                        <td>Centro </td>
                        
                    </tr>
                    <tr>
                        <td>Ernst Handel</td>
                        <td>Roland Mendel</td>
                        <td>Austria</td>
                        <td>Ernst Handel</td>
                        <td>Roland Mendel</td>
                        <td>Austria</td>
                        <td>Ernst Handel</td>
                        
                    </tr>
                    <tr>
                        <td>Island Trading</td>
                        <td>Helen Bennett</td>
                        <td>UK</td>
                        <td>Island Trading</td>
                        <td>Helen Bennett</td>
                        <td>UK</td>
                        <td>Island Trading</td>
                        
                    </tr>
                    <tr>
                        <td>Laughing </td>
                        <td>Yoshi Tannamuri</td>
                        <td>Canada</td>
                        <td>Laughing </td>
                        <td>Yoshi Tannamuri</td>
                        <td>Canada</td>
                        <td>Laughing </td>
                       
                    </tr>
                    <tr>
                        <td>Magazzini</td>
                        <td>Giovanni Rovelli</td>
                        <td>Italy</td>
                        <td>Magazzini</td>
                        <td>Giovanni Rovelli</td>
                        <td>Italy</td>
                        <td>Magazzini</td>
                       
                    </tr>
                </table>
            </div>
            <div class="popup-comtainer">
                <div class="card_add">
                    <div class="addnew">
                        <form action="">
                            <div class="close"><i class="fas fa-times"></i></div>
                            <h2 style="margin-top:20px; margin-left:20px; color:white; font-weight: bolder;">ADD NEW LICENCE</h2>
                            <label  for="fname">Licence:</label>
                            <input type="text" id="Title" class="textbox" style="margin-left: 100px;">
                            <select id ="textbox"> 
                            <option value ="1year">1 Year</option>
                            <option value ="1year">3 Year</option>
                            <option value ="1year">10 Year</option>
                            <option value ="1year">Lifetime</option>
                            </select> 
                            <br>

                            <label  for="fname">Product Key:</label>
                            <input type="text" id="Title" class="textbox" style="margin-left: 63px;"><br>

                            <label  for="fname">Expiry Date:</label>
                            <input type="text" id="Title" class="textbox" style="margin-left: 63px;" pattern ="^([0-2][0-9]|(3)[0-1])(\/)(((0)[0-9])|((1)[0-2]))(\/)\d{4}$"><br>

                            <label  for="fname">Remaining sets:</label>
                            <input type="text" id="Title" class="textbox" style="margin-left: 37px;" pattern = "^[0-9]{1,45}$"><br>

                            <label  for="fname">Licences to mail:</label>
                            <input type="text" id="Title" class="textbox" style="margin-left: 30px;" ><br>

                            <label  for="fname">Author:</label>
                            <input type="text" id="Title" class="textbox" style="margin-left: 105px;"><br>

                            <label  for="fname">Manufacturer:</label>
                            <input type="text" id="Title" class="textbox" style="margin-left: 48px;" ><br>

                            <input type="submit" value="SUBMIT" class="add-btn">
                        </form>
                    </div>
                </div>
                <!-- <div class="close"><i class="fas fa-times"></i></div> -->
            </div>
            <script src="popup.js"></script>