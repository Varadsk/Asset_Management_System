<?php
    session_start();
    include("headertable.php");
    @mysql_connect('localhost', 'root', '')or die('cannot connectssss'); 
    mysql_select_db('assetm')or die('cannot select DB');
    $sql="SELECT * FROM  `asset_disposed`"; 
    $result=mysql_query($sql);
    if($result==false ){die(mysql_error());}
    $row=mysql_fetch_array($result);  
    $count=mysql_num_rows($result);
?>
    <div id="one" class="slideswitch"></div>
    <div id="two" class="slideswitch"></div>

    <div class="pagination">
        <a id="pagination_one" href="#one"><i class="fas fa-chevron-left"></i></a>
        <a id="pagination_two" href="#two"><i class="fas fa-chevron-right"></i></a>
    </div>

    <div class="wrapper">
        <div id="one" class="section">
            <?php
                include("tablesidebar.php");
            ?>
            <div class="tablecrd">
            <form action="del.php" method="POST">
                <table class="table0" style="margin-top = 35px;">
                    <thead>
                        <tr>
                            <th style="min-width: 170px">Asset Name</th>
                            <th style="min-width: 170px">Asset Tag</th>
                            <th style="min-width: 170px">Serial</th>
                            <th style="min-width: 170px">Model</th>
                            <th style="min-width: 170px">Category</th>
                            <th style="min-width: 170px">Status</th>
                            <th style="min-width: 170px">Checked Out To</th>
                            <th style="min-width: 170px">Location</th>
                            <th style="min-width: 170px">Purches</th>
                            <th style="min-width: 170px">Action</th>
                        </tr>
                    </thead>
                    <?php
                        // $count= mysql_num_rows($count)
                        //echo $count;
                        for ($i=0; $i<$count; $i++) { 
                            $id = $row['id'];
                            $Asset_name=$row['Asset_name'];
                            $Asset_tag=$row['Asset_tag'];
                            $serial=$row['serial'];
                            $model=$row['model'];
                            $category=$row['category'];
                            $status=$row['status'];
                            $checkout_to=$row['checkout_to'];
                            $location=$row['location'];
                            $purchase_cost=$row['purchase_cost'];
                    ?>
                    <tr>
                        <td>
                            <?php
                                echo $Asset_name;
                            ?>
                        </td>
                        <td>
                            <?php
                                echo $Asset_tag;
                            ?>
                        </td>
                        <td>
                            <?php
                                echo $serial;
                            ?>
                        </td>
                        <td>
                            <?php
                                echo $model;
                            ?>
                        </td>
                        <td>
                            <?php
                                echo $category;
                            ?>
                        </td>
                        <td>
                            <?php
                                echo $status;
                            ?>
                        </td>
                        <td>
                            <?php
                                echo $checkout_to;
                            ?>
                        </td>
                        <td>
                            <?php
                                echo $location;
                            ?>
                        </td>
                        <td>
                            <?php
                                echo $purchase_cost;
                            ?>
                        </td>
                    </tr>
                    <?php
                            $row=mysql_fetch_array($result);  
                        }
                    ?>
                </table>
            </form>
        </div>
        </div>               
<script src="popup.js"></script>