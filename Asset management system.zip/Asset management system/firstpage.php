<?php
    include("Header.php");
    @mysql_connect('localhost', 'root', '')or die('cannot connectssss'); 
    mysql_select_db('assetm')or die('cannot select DB');
    $sql="SELECT * FROM  `asset`"; 
    $result=mysql_query($sql);
    if($result==false ){die(mysql_error());}
    $row=mysql_fetch_array($result);  
    $count=mysql_num_rows($result);
?>
    <div class="menubar">
        <!-- <h2 style="margin-right: 1140px; margin-top : 15px; color:brown;">DASHBOARD</h2>	 -->
        <ul>
            <div class="wrap">
                <div class="search">
                    <input type="text" class="searchTerm" placeholder="Search..." style="height: 90%;">
                    <button type="submit" class="searchButton">
                        <i class="fa fa-search"></i>
                    </button>
                </div>
            </div>
            <select name = "course">
                <option value ="ADMIN" style="padding-top: 5px;">ADMIN</option>
                <option value ="VK">VK</option>
            </select>
        </ul>
	</div>
    <a href = "#">
        <div class="card" style="margin-left: 230px; margin-top: 60px; background-color: rgba(166, 255, 0,0.8);">
        <h1 class="totalno"><?php echo $count?></h1>    
        <div class="title1">
                <h2>total assets</h2>
            </div> 
        </div>
    </a>
    <a href = "#">
        <div class="card" style="margin-left: 20px; margin-top: 60px;background-color: rgb(0, 255, 221,0.8);">
        <h1 class="totalno"><?php echo $count?></h1>    
        <div class="title2">
                <h2>total  licenses</h2>   
            </div>
        </div>
    </a>
    <a href = "#">
        <div class="card" style="margin-left: 20px; margin-top: 60px; background-color: rgb(255, 238, 0,0.8);">
        <h1 class="totalno"><?php echo $count?></h1>    
        <div class="title3">
                <h2>total accessories</h2>  
            </div> 
        </div>
    </a>
    <!-- <div class="card1">   
    </div> -->
    <div class="tablecrd">
        <table class="tablel" style="margin-top: 30px;">
            <thead>
                <tr>
                    <th>Asset Name</th>
                    <th>Serial number</th>
                    <th>Checkout to</th>
                    <th>Location</th>
                </tr>
            </thead>
            <tr>
                <td>Dell_Optiplex_390 </td>
                <td>D1201</td>
                <td>Admin</td>
                <td>Sales Department</td>
                
            </tr>
            <tr>
                <td>Cnc Machine</td>
                <td>CM121</td>
                <td>User1</td>
                <td>Production Department </td>
            </tr>
            <tr>
                <td>3D Printing  Machine</td>
                <td>3pm1</td>
                <td>User1</td>
                <td>Production Department</td>
            </tr>
            <tr>
                <td>Network Switch</td>
                <td>nm_121t</td>
                <td>user2</td>
                <td>Accounts Department</td>
            </tr>
            <tr>
                <td>Projector </td>
                <td>assm_123</td>
                <td>user3</td>
                <td>Marketing </td>

            </tr>
            <tr>
                <td>Table Fan</td>
                <td>assm_125</td>
                <td>user3</td>
                <td>Marketing</td>
                
            </tr>
        </table>
    </div>
</body>
</html>