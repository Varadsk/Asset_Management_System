document.getElementById('button').addEventListener('click', function(){
    document.querySelector('.popup-comtainer').style.display = 'flex';
});

document.querySelector('.close').addEventListener('click', function(){
    document.querySelector('.popup-comtainer').style.display = 'none';
});