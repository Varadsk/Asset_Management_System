<?php
  include("string.fnc")
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>ASSET MANAGEMENT</title>
    <link rel="stylesheet" href="css\firstpage.css">
    <link rel="stylesheet" href="css\table.css">
    <link rel="stylesheet" href="css\ltable.css">
    <link rel="stylesheet" href="css\form.css">
	<script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
    <script src="js\wall.js"></script>
</head>
<body>

<div class="wrapper">
    <div class="sidebar">
        <h3>ASSET MANAGEMENT</h3>
        <ul>
            <li><a href="firstpage.php"><i class="fa fa-home" aria-hidden="true"></i>  HOME</a></li>
            <li><a href="#"><i class="fas fa-barcode"></i>  ASSETS</a>
                <div class="submenu">
					<ul>
						<li><a href="asset1.php"><i class="far fa-circle"></i> ALL DEPLOYED</a></li>
						<li><a href="asset2.php"><i class="far fa-circle"></i> ALL READY TO DEPLOYED</a></li>
						<!-- <li><a href="asset3.php"><i class="far fa-circle" style = "color = red"></i> ALL PENDING</a></li>
						<li><a href="asset4.php"><i class="fas fa-times"></i>ALL UN-DEPLOYED</a></li>
                        <li><a href="asset5.php"><i class="fas fa-times"></i>ALL ARCHIVED</a></li>
                        <li><a href="asset6.php"><i class="fas fa-check"></i>REQUESTABLE</a></li>
                        <li><a href="asset7.php"><i class="far fa-clock"></i> DUE FOR AUDIT</a></li>
                        <li><a href="asset8.php"><i class="fas fa-exclamation-triangle"></i>OVERDUE FOR AUDIT</a></li> -->
                        <li><a href="#">REQUESTED</a></li>
					</ul>
				</div>
            </li>
            <li><a href="alldep.php"><i class="fas fa-id-badge"></i>  LICENSES</a></li>
            <li><a href="people.php"><i class="fas fa-users"></i>  PEOPLE</a></li>
            <li><a href="#"><i class="far fa-file"></i>  REPORT</a>
                <div class="submenu">
					<ul>
						<li><a href="#"><i class="fas fa-chart-line"></i> ACTIVITY REPORT</a></li>
                        <li><a href="#"><i class="fas fa-id-badge"></i>LICENCE REPORT</a></li>
					</ul>
				</div>
            </li> 
            <li><a href="#"><i class="fas fa-exchange-alt"></i>  TRANSFER</a></li>   
            <li><a href="#"><i class="fas fa-id-badge"></i>  DISPOSED</a>
                <div class="submenu">
					<ul>
						<li><a href="asset dispose.php"><i class="fas fa-barcode"></i> ASSET</a></li>
						<li><a href="#"><i class="fas fa-id-badge"></i> LICENSES</a></li>
                        <li><a href="#"><i class="fas fa-users"></i>PEOPLE</a></li>
					</ul>
				</div>
            </li>
            <!-- <li><a href="#"><i class="fas fa-cloud-download-alt"></i>  IMPORT</a></li> -->
            <!-- <li><a href="#"><i class="fas fa-chart-bar"></i>  REPORT</a>
                <div class="submenu">
					<ul>
						<li><a href="activity_repo.php">ACTIVITY REPORT</a></li>
						<li><a href="Audit_repo.php">AUDIT REPORT</a></li>
						<li><a href="#">DEPRECIATION REPORT</a></li>
						<li><a href="licence_report.php">LICENSES REPORT</a></li>
						<li><a href="#">ASSET MAINTENANCE REPORT</a></li>
					</ul>
				</div>
            </li> -->
            <li><a href="about.php"><i class="fa fa-user" aria-hidden="true"></i>  ABOUT</a></li>
            <li><a href="contact.php"><i class="fa fa-question-circle" aria-hidden="true">  HELP</i></a></li>
        </ul>
    </div>
</div>